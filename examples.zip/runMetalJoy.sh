#!/bin/bash
/home/pi/metalborg/metalJoy.py > /dev/null

