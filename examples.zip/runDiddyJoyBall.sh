#!/bin/bash
/home/pi/metalborg/metalJoyBall.py > /dev/null

